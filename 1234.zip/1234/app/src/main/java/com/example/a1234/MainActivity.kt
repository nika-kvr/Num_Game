package com.example.a1234

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import android.content.Intent as Intent
import com.example.a1234.Main2Activity as Main2Activity1

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        play.setOnClickListener {
            startActivity(Intent(this, com.example.a1234.Main2Activity::class.java))
        }

        rules.setOnClickListener {
            startActivity(Intent(this, Main3Activity::class.java))
        }


    }
}

